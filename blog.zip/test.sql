-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- ホスト: 127.0.0.1
-- 生成日時: 2024-02-12 07:11:17
-- サーバのバージョン： 8.0.31
-- PHP のバージョン: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- データベース: `test`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `articles`
--

CREATE TABLE `articles` (
  `id` int NOT NULL,
  `subject` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `author` varchar(255) NOT NULL,
  `modified` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- テーブルのデータのダンプ `articles`
--

INSERT INTO `articles` (`id`, `subject`, `body`, `author`, `modified`) VALUES
(3, 'サマータイムの魅力', '今年の夏は特別です。ビーチでの楽しみ、太陽の光、そして冷たいアイスクリームについて話しましょう。', '5', '2024-01-25 16:24:15'),
(4, '旅行記：京都の美', '京都の美しさと伝統文化についての素晴らしい旅行経験を共有します。', '7', '2024-01-25 16:24:47'),
(5, 'クリエイティブなアイデアの発見', 'アイデアを生み出す方法と、クリエイティブなプロジェクトに取り組む楽しみについて考えます。', '8', '2024-01-25 16:25:18'),
(6, '料理の楽しさ：新しいレシピを試す', '料理愛好家のために、新しい料理レシピの探求がどれほど楽しいかを語ります。', '8', '2024-01-25 16:25:34'),
(7, '自然の癒し：森林浴の効果', '自然に包まれることが心と体に与える癒しの力について紹介します。', '9', '2024-01-25 16:25:57'),
(8, 'マインドフルネス瞑想の力 ', 'マインドフルネス瞑想が日常生活にもたらす平静と精神的な健康に焦点を当てます。', '10', '2024-01-25 16:26:26'),
(17, 'サマータイムの魅力', '今年の夏は特別です。ビーチでの楽しみ、太陽の光、そして冷たいアイスクリームについて話しましょう。', '14', '2024-02-04 11:16:39');

-- --------------------------------------------------------

--
-- テーブルの構造 `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- テーブルのデータのダンプ `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(5, 'サクラパン', '$2y$10$13vsn0UD8uDHJCv3RiMtpeQSxWqEDmvMRQ1IRISYFEKJPjt5wH1Qe'),
(7, 'ひなたぼっこ', '1'),
(8, 'たんぽぽの夢', '$2y$10$lvxlGiCf9ihgRh0gE.qateynNoG0UfBKQpij3CPl7fGZWSyLvG.0K'),
(9, '月夜の詩人', '$2y$10$Q./4GOSINt5jtsQDnRuEsup61tPVpBDAuLsZpIwjibg05Gn2LoTTu'),
(10, 'さくらんぼ好き', '$2y$10$0qDcWj5zZEgjZk8APY7Um.2cYddiOFtJU.Bu4mhLlCuxcb0ZRGdMm'),
(12, '1', '$2y$10$ATCNbSQBh2ezeEEqVjv9benu4j0p7Y0uXYEHnUKXQ1p2oOYOy.4IC'),
(14, '2', '$2y$10$.v8xqdnEen34YSoO7m3KkueGSXSI3WoM/vA1qZt.SvmPARNBjCnoW'),
(15, '123', '$2y$10$HoOU5t8swo.FD/MYuHgJl.lSjxnGsVnNROp9aQxIv5OHcItgQ7FYq');

--
-- ダンプしたテーブルのインデックス
--

--
-- テーブルのインデックス `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- テーブルのインデックス `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- ダンプしたテーブルの AUTO_INCREMENT
--

--
-- テーブルの AUTO_INCREMENT `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- テーブルの AUTO_INCREMENT `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
