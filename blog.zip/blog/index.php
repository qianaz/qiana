<?php
include 'connect.php';
session_start();

$articles = $pdo->query('SELECT articles.*, users.username AS author_name FROM articles JOIN users ON articles.author = users.id ORDER BY articles.modified DESC')->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>ブログ</title>
    <link rel="stylesheet" href="css/index.css">
</head>
<body>
    <div class="container"> 
        <h1>私のブログへようこそ</h1>
        <?php if (isset($_SESSION['user_id'])): ?>
            <p>&nbsp;ログイン済み &nbsp; <a href="admin/profile.php">Profile</a> | <a href="admin/logout.php">Logout</a></p>

        <!-- 新規記事作成 -->
        <h2>新規記事の作成</h2>
        <form action="article/submit_article.php" method="post">
            <label for="subject">タイトル:</label><br>
            <input type="text" id="subject" name="subject" required><br>
            <label for="body">コンテンツ:</label><br>
            <textarea id="body" name="body" required></textarea><br>
            <input type="submit" value="送信">
        </form>
        <?php else: ?>
            <p>ログインしていません. <a href="admin/login.php">Login</a> or <a href="admin/register.php">Register</a></p>
        <?php endif; ?>

        <!-- 検索 -->
        <form action="article/search.php" method="post">
            <label for="search_term">検索用語:</label>
            <input type="text" id="search_term" name="search_term" required>
            <input type="submit" value="検索">
        </form>

        <!-- 表示 -->
        <div class="articles-container">
            <?php foreach ($articles as $article): ?>
                <div class="article">
                    <div class="article-author">By <?php echo htmlspecialchars($article['author_name']); ?></div>

                    <h3><a href="article/show_article.php?id=<?php echo $article['id']; ?>"><?php echo htmlspecialchars($article['subject']); ?></a></h3>
                    <p class="article-body"><?php echo nl2br(htmlspecialchars($article['body'])); ?></p>
                    <p class="article-info">Posted on <?php echo date('F j, Y', strtotime($article['modified'])); ?></p>
                    <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $article['author']): ?>
                        <div class="article-actions">
                            <a href="article/edit_article.php?id=<?php echo $article['id']; ?>">編集</a> |
                            <a href="article/delete_article.php?id=<?php echo $article['id']; ?>">削除</a>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div> 
</body>
</html>