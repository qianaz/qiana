<?php
include '../connect.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['user_id'])) {
    $subject = $_POST['subject'];
    $body = $_POST['body'];
    $author = $_SESSION['user_id'];

    $stmt = $pdo->prepare('INSERT INTO articles (subject, body, author) VALUES (?, ?, ?)');
    if ($stmt->execute([$subject, $body, $author])) {
        header('Location: ../index.php');
    } else {
        echo 'ブログの投稿に失敗しました';
    }
}
?>
