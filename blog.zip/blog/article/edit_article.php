<?php
include '../connect.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

$article_id = isset($_GET['id']) ? $_GET['id'] : null;

if ($_SERVER['REQUEST_METHOD'] == 'GET' && $article_id !== null) {
    $user_id = $_SESSION['user_id'];

    // ブログを編集する可能性があるかどうかをチェック
    $stmt = $pdo->prepare('SELECT * FROM articles WHERE id = ? AND author = ?');
    $stmt->execute([$article_id, $user_id]);
    $article = $stmt->fetch();

    if (!$article) {
        header('Location: ../index.php');
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $article_id !== null) {
    if (isset($_POST['subject']) && isset($_POST['body'])) {
        $subject = $_POST['subject'];
        $body = $_POST['body'];

        $stmt = $pdo->prepare('UPDATE articles SET subject = ?, body = ? WHERE id = ?');
        if ($stmt->execute([$subject, $body, $article_id])) {
            header('Location: ../index.php');
            exit;
        } else {
            echo 'ブログの更新に失敗しました';
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>編集</title>
    <link rel="stylesheet" href="../css/edit.css">
</head>
<body>
    <h2>記事の編集</h2>
    <form action="edit_article.php?id=<?= $article_id ?>" method="post">
        <label for="subject">タイトル:</label><br>
        <input type="text" id="subject" name="subject" value="<?= htmlspecialchars($article['subject']) ?>" required><br>
        <label for="body">コンテンツ:</label><br>
        <textarea id="body" name="body" required><?= htmlspecialchars($article['body']) ?></textarea><br>
        <input type="submit" value="Save">
    </form>
</body>
</html>