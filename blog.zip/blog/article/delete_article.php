<?php
include '../connect.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['id'])) {
    $article_id = $_GET['id'];
    
    // ブログを削除する可能性があるかどうかをチェック
    $stmt = $pdo->prepare('SELECT * FROM articles WHERE id = ? AND author = ?');
    $stmt->execute([$article_id, $_SESSION['user_id']]);
    
    if (!$stmt->fetch()) {
        header('Location: ../index.php');
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['confirm'])) {
    $article_id = $_GET['id']; 
    
    // ブログの削除
    $stmt = $pdo->prepare('DELETE FROM articles WHERE id = ?');
    if ($stmt->execute([$article_id])) {
        header('Location: ../index.php');
        exit;
    } else {
        echo 'ブログ削除に失敗しました';
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>記事削除</title>
    <link rel="stylesheet" href="../css/delete.css">
</head>
<body>
    <h2>記事削除</h2>
    <p>この記事を削除しますか？</p>
    <form action="delete_article.php?id=<?= $article_id ?>" method="post">
        <input type="checkbox" name="confirm" required> はい<br>
        <input type="submit" value="Delete">
    </form>
</body>
</html>