<?php
include '../connect.php'; 
$id = isset($_GET['id']) ? $_GET['id'] : ''; 


$query = $pdo->prepare("SELECT articles.*, users.username AS author_name FROM articles JOIN users ON articles.author = users.id WHERE articles.id = ?");
$query->execute([$id]);
$article = $query->fetch(PDO::FETCH_ASSOC);

if (!$article) {
    echo "Article not found!";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title><?php echo htmlspecialchars($article['subject']); ?></title>
    <link rel="stylesheet" href="../css/show_article.css">
</head>
<body>
    <div class="container">
        <h1><?php echo htmlspecialchars($article['subject']); ?></h1>
        <p><?php echo nl2br(htmlspecialchars($article['body'])); ?></p>
        <p class="author-date">Posted by <?php echo htmlspecialchars($article['author_name']); ?> on <?php echo date('F j, Y', strtotime($article['modified'])); ?></p>
        <a href="../index.php">ブログリストに戻る</a>
    </div>
</body>
</html>