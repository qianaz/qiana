<?php
include '../connect.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $search_term = isset($_POST['search_term']) ? $_POST['search_term'] : '';

    $stmt = $pdo->prepare('SELECT articles.*, users.username AS author FROM articles JOIN users ON articles.author = users.id WHERE subject LIKE ? OR body LIKE ? OR users.username LIKE ? ORDER BY articles.modified DESC');
    $search_term = '%' . $search_term . '%'; 
    $stmt->execute([$search_term, $search_term, $search_term]);
    $search_results = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>検索</title>
    <link rel="stylesheet" href="../css/search.css"> 
</head>
<body>
    <h1>検索結果</h1>
    
    <!-- 検索結果を表示 -->
    <?php if (isset($search_results) && count($search_results) > 0): ?>
        <ul>
            <?php foreach ($search_results as $result): ?>
                <li>
                    <h3><a href="show_article.php?id=<?php echo $result['id']; ?>"><?php echo htmlspecialchars($result['subject']); ?></a></h3>
                    <p><?php echo nl2br(htmlspecialchars($result['body'])); ?></p>
                    <p>Posted by <?php echo htmlspecialchars($result['author']); ?> on <?php echo $result['modified']; ?></p>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php elseif (isset($search_results) && count($search_results) === 0): ?>
        <p class="no-results">結果が見つかりませんでした</p>
    <?php endif; ?>
</body>
</html>