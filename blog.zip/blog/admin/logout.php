<?php
session_start();
session_unset(); // セッション変数の消去
session_destroy(); // 
header('Location: login.php'); // 
exit;