<?php
include '../connect.php';
session_start();
$message = '';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$user = $pdo->query("SELECT * FROM users WHERE id = $user_id")->fetch();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['username']) && isset($_POST['password'])) {
        $new_username = trim($_POST['username']);
        $new_password = password_hash($_POST['password'], PASSWORD_BCRYPT);

        $stmt = $pdo->prepare('UPDATE users SET username = ?, password = ? WHERE id = ?');
        if ($stmt->execute([$new_username, $new_password, $user_id])) {
            $message = '情報が更新されました';
        } else {
            $message = '情報の更新に失敗しました';
        }
    }
}

if (isset($_POST['delete_account'])) {
    // ユーザーアカウントと関連ブログレコードの削除
    $pdo->query("DELETE FROM users WHERE id = $user_id");
    $pdo->query("DELETE FROM articles WHERE author = $user_id");
    session_unset();
    session_destroy();
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Profile</title>
    <link rel="stylesheet" href="../css/all.css">
</head>
<body>
    <h2>ユーザー情報の変更</h2>
    <?php if (!empty($message)): ?>
        <p><?= $message ?></p>
    <?php endif; ?>
    <form action="profile.php" method="post">
        <label for="username">新規ユーザー名:</label>
        <input type="text" name="username" id="username" value="<?= $user['username'] ?>" required>
        <label for="password">新しいパスワード:</label>
        <input type="password" name="password" id="password" required>
        <input type="submit" value="更新">
    </form>
    <form action="profile.php" method="post">
        <input type="submit" name="delete_account" value="アカウント削除">
    </form>
    <a href="../index.php">ブログに戻る</a>
</body>
</html>