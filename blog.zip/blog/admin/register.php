<?php
include '../connect.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['username']) && isset($_POST['password'])) {
        $username = trim($_POST['username']);
        

        $stmt = $pdo->prepare('INSERT INTO users (username, password) VALUES (?, ?)');
        if ($stmt->execute([$username, $password])) {
            $message = 'ユーザーの登録に成功しました';
        } else {
            $message = 'ユーザー登録に失敗しました';
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>登録</title>
    <link rel="stylesheet" href="../css/all.css">
</head>
<body>
    <h2>新規ユーザーの登録</h2>
    <?php if (!empty($message)): ?>
        <p><?= $message ?></p>
    <?php endif; ?>
    <form action="register.php" method="post">
        <label for="username">ユーザー名:</label>
        <input type="text" name="username" id="username" required>
        <label for="password">パスワード:</label>
        <input type="password" name="password" id="password" required>
        <input type="submit" value="登録">
    </form>
</body>
</html>