<?php
include '../connect.php'; 
session_start();

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        header('Location: ../index.php'); 
        exit;
    } else {
        $message = 'ログイン情報エラー';
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>ログイン</title>
    <link rel="stylesheet" href="../css/all.css">
</head>
<body>
    <div class="login-container">
        <h2>ユーザーログイン</h2>
        <?php if (!empty($message)): ?>
            <p><?php echo $message; ?></p>
        <?php endif; ?>
        <form action="login.php" method="post">
            <label for="username">ユーザー名:</label><br>
            <input type="text" id="username" name="username" required><br>
            <label for="password">パスワード:</label><br>
            <input type="password" id="password" name="password" required><br>
            <input type="submit" value="ログイン">
        </form>
    </div>
</body>
</html>